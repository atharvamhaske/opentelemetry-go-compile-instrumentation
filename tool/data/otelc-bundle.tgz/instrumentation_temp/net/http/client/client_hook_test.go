// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

package client

import (
	"context"
	"errors"
	"net/http"
	"net/http/httptest"
	"net/url"
	"sync"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/codes"
	"go.opentelemetry.io/otel/propagation"
	sdktrace "go.opentelemetry.io/otel/sdk/trace"
	"go.opentelemetry.io/otel/sdk/trace/tracetest"
	"go.opentelemetry.io/otel/trace"

	"go.opentelemetry.io/otelc/pkg/hook"
	"go.opentelemetry.io/otelc/pkg/hook/hooktest"
)

func setupTestTracer(t *testing.T) (*tracetest.SpanRecorder, *sdktrace.TracerProvider) {
	t.Helper()
	sr := tracetest.NewSpanRecorder()
	tp := sdktrace.NewTracerProvider(sdktrace.WithSpanProcessor(sr))
	otel.SetTracerProvider(tp)
	otel.SetTextMapPropagator(propagation.TraceContext{})
	t.Cleanup(func() { _ = tp.Shutdown(context.Background()) })
	return sr, tp
}

func TestBeforeRoundTrip(t *testing.T) {
	tests := []struct {
		name            string
		setupEnv        func(t *testing.T)
		setupRequest    func() *http.Request
		expectSpan      bool
		validateSpan    func(*testing.T, trace.Span)
		validateRequest func(*testing.T, *http.Request)
	}{
		{
			name: "basic request creates span",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp")
			},
			setupRequest: func() *http.Request {
				req, _ := http.NewRequest("GET", "http://example.com/path", nil)
				return req
			},
			expectSpan: true,
			validateSpan: func(t *testing.T, span trace.Span) {
				assert.NotNil(t, span)
			},
			validateRequest: func(t *testing.T, req *http.Request) {
				// Should have trace headers injected
				assert.NotEmpty(t, req.Header.Get("traceparent"))
			},
		},
		{
			name: "instrumentation disabled",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_DISABLED_INSTRUMENTATIONS", "nethttp")
			},
			setupRequest: func() *http.Request {
				req, _ := http.NewRequest("GET", "http://example.com/path", nil)
				return req
			},
			expectSpan: false,
		},
		{
			name: "OTel exporter request filtered",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp")
			},
			setupRequest: func() *http.Request {
				req, _ := http.NewRequest("POST", "http://localhost:4318/v1/traces", nil)
				req.Header.Set("User-Agent", "OTel OTLP Exporter Go/1.0")
				return req
			},
			expectSpan: false,
		},
		{
			name: "POST request",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp")
			},
			setupRequest: func() *http.Request {
				req, _ := http.NewRequest("POST", "http://example.com/api/data", nil)
				return req
			},
			expectSpan: true,
		},
		{
			name: "request with existing context",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp")
			},
			setupRequest: func() *http.Request {
				ctx := context.WithValue(context.Background(), "test-key", "test-value")
				req, _ := http.NewRequestWithContext(ctx, "GET", "http://example.com/path", nil)
				return req
			},
			expectSpan: true,
		},
		{
			name: "nil request does not panic",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp")
			},
			setupRequest: func() *http.Request {
				return nil
			},
			expectSpan: false,
		},
		{
			name: "request with nil Header does not panic and injects trace headers",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp")
			},
			setupRequest: func() *http.Request {
				u, _ := url.Parse("http://example.com/path")
				return &http.Request{
					Method: http.MethodGet,
					URL:    u,
					Header: nil,
				}
			},
			expectSpan: true,
			validateRequest: func(t *testing.T, req *http.Request) {
				require.NotNil(t, req.Header)
				assert.NotEmpty(t, req.Header.Get("traceparent"))
			},
		},
		{
			name: "request with nil URL does not panic",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp")
			},
			setupRequest: func() *http.Request {
				return &http.Request{
					Method: http.MethodGet,
					URL:    nil,
					Header: make(http.Header),
				}
			},
			expectSpan: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Reset initialization for each test by creating a new once
			initOnce = *new(sync.Once)

			tt.setupEnv(t)
			sr, _ := setupTestTracer(t)

			req := tt.setupRequest()
			mockCtx := hooktest.NewMockHookContext()
			transport := &http.Transport{}

			BeforeRoundTrip(mockCtx, transport, req)

			if tt.expectSpan {
				spans := sr.Ended()
				// Span should not be ended yet in Before hook
				assert.Equal(t, 0, len(spans), "span should not be ended in Before hook")

				// Check that data was stored
				data, ok := mockCtx.GetData().(*hookData)
				require.True(t, ok, "data should be stored")
				require.NotNil(t, data, "data should not be nil")

				span := data.span
				require.NotNil(t, span, "span should not be nil")

				if tt.validateSpan != nil {
					tt.validateSpan(t, span)
				}

				// Check that request was updated with new context
				newReq, ok := mockCtx.GetParam(1).(*http.Request)
				require.True(t, ok, "param 1 should be request")
				require.NotNil(t, newReq, "updated request should not be nil")

				if tt.validateRequest != nil {
					tt.validateRequest(t, newReq)
				}
			} else {
				// No span should be created
				data := mockCtx.GetData()
				assert.Nil(t, data, "no data should be stored when instrumentation disabled")
			}
		})
	}
}

func TestAfterRoundTrip(t *testing.T) {
	tests := []struct {
		name         string
		setupEnv     func(t *testing.T)
		setupContext func(*sdktrace.TracerProvider) hook.HookContext
		response     *http.Response
		err          error
		validateSpan func(*testing.T, []sdktrace.ReadOnlySpan)
	}{
		{
			name: "successful response",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp")
			},
			setupContext: func(tp *sdktrace.TracerProvider) hook.HookContext {
				testTracer := tp.Tracer(instrumentationName)
				_, span := testTracer.Start(context.Background(), "GET", trace.WithSpanKind(trace.SpanKindClient))

				mockCtx := hooktest.NewMockHookContext()
				mockCtx.SetData(&hookData{span: span})
				return mockCtx
			},
			response: &http.Response{
				StatusCode: 200,
				Request:    httptest.NewRequest("GET", "http://example.com/path", nil),
			},
			err: nil,
			validateSpan: func(t *testing.T, spans []sdktrace.ReadOnlySpan) {
				require.Len(t, spans, 1)
				span := spans[0]
				assert.Equal(t, codes.Unset, span.Status().Code)
			},
		},
		{
			name: "error response",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp")
			},
			setupContext: func(tp *sdktrace.TracerProvider) hook.HookContext {
				testTracer := tp.Tracer(instrumentationName)
				_, span := testTracer.Start(context.Background(), "GET", trace.WithSpanKind(trace.SpanKindClient))

				mockCtx := hooktest.NewMockHookContext()
				mockCtx.SetData(&hookData{span: span})
				return mockCtx
			},
			response: nil,
			err:      errors.New("connection refused"),
			validateSpan: func(t *testing.T, spans []sdktrace.ReadOnlySpan) {
				require.Len(t, spans, 1)
				span := spans[0]
				assert.Equal(t, codes.Error, span.Status().Code)
				assert.Contains(t, span.Status().Description, "connection refused")

				// Check that error was recorded
				events := span.Events()
				require.Len(t, events, 1)
				assert.Equal(t, "exception", events[0].Name)
			},
		},
		{
			name: "4xx client error",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp")
			},
			setupContext: func(tp *sdktrace.TracerProvider) hook.HookContext {
				testTracer := tp.Tracer(instrumentationName)
				_, span := testTracer.Start(context.Background(), "GET", trace.WithSpanKind(trace.SpanKindClient))

				mockCtx := hooktest.NewMockHookContext()
				mockCtx.SetData(&hookData{span: span})
				return mockCtx
			},
			response: &http.Response{
				StatusCode: 404,
				Request:    httptest.NewRequest("GET", "http://example.com/path", nil),
			},
			err: nil,
			validateSpan: func(t *testing.T, spans []sdktrace.ReadOnlySpan) {
				require.Len(t, spans, 1)
				span := spans[0]
				// 4xx is an error for HTTP client requests per OTel HTTP semconv
				assert.Equal(t, codes.Error, span.Status().Code)
			},
		},
		{
			name: "5xx server error",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp")
			},
			setupContext: func(tp *sdktrace.TracerProvider) hook.HookContext {
				testTracer := tp.Tracer(instrumentationName)
				_, span := testTracer.Start(context.Background(), "GET", trace.WithSpanKind(trace.SpanKindClient))

				mockCtx := hooktest.NewMockHookContext()
				mockCtx.SetData(&hookData{span: span})
				return mockCtx
			},
			response: &http.Response{
				StatusCode: 500,
				Request:    httptest.NewRequest("GET", "http://example.com/path", nil),
			},
			err: nil,
			validateSpan: func(t *testing.T, spans []sdktrace.ReadOnlySpan) {
				require.Len(t, spans, 1)
				span := spans[0]
				assert.Equal(t, codes.Error, span.Status().Code)
			},
		},
		{
			name: "no data in context",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp")
			},
			setupContext: func(tp *sdktrace.TracerProvider) hook.HookContext {
				return hooktest.NewMockHookContext()
			},
			response: &http.Response{
				StatusCode: 200,
				Request:    httptest.NewRequest("GET", "http://example.com/path", nil),
			},
			err: nil,
			validateSpan: func(t *testing.T, spans []sdktrace.ReadOnlySpan) {
				// No span should be ended
				assert.Equal(t, 0, len(spans))
			},
		},
		{
			name: "instrumentation disabled",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_DISABLED_INSTRUMENTATIONS", "nethttp")
			},
			setupContext: func(tp *sdktrace.TracerProvider) hook.HookContext {
				testTracer := tp.Tracer(instrumentationName)
				_, span := testTracer.Start(context.Background(), "GET", trace.WithSpanKind(trace.SpanKindClient))

				mockCtx := hooktest.NewMockHookContext()
				mockCtx.SetData(&hookData{span: span})
				return mockCtx
			},
			response: &http.Response{
				StatusCode: 200,
				Request:    httptest.NewRequest("GET", "http://example.com/path", nil),
			},
			err: nil,
			validateSpan: func(t *testing.T, spans []sdktrace.ReadOnlySpan) {
				// The span should still be ended when instrumentation is disabled.
				assert.Equal(t, 1, len(spans))
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			// Reset initialization for each test by creating a new once
			initOnce = *new(sync.Once)

			tt.setupEnv(t)
			sr, tp := setupTestTracer(t)

			mockCtx := tt.setupContext(tp)

			AfterRoundTrip(mockCtx, tt.response, tt.err)

			spans := sr.Ended()
			if tt.validateSpan != nil {
				tt.validateSpan(t, spans)
			}
		})
	}
}

func TestClientEnabler(t *testing.T) {
	tests := []struct {
		name     string
		setupEnv func(t *testing.T)
		expected bool
	}{
		{
			name: "enabled explicitly",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp")
			},
			expected: true,
		},
		{
			name: "disabled explicitly",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_DISABLED_INSTRUMENTATIONS", "nethttp")
			},
			expected: false,
		},
		{
			name: "not in enabled list",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "grpc")
			},
			expected: false,
		},
		{
			name: "default enabled when no env set",
			setupEnv: func(t *testing.T) {
				// No environment variables set - should be enabled by default
			},
			expected: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			tt.setupEnv(t)

			enabler := netHttpClientEnabler{}
			result := enabler.Enable()
			assert.Equal(t, tt.expected, result)
		})
	}
}

func TestAfterRoundTrip_DisabledAfterStart_Regression(t *testing.T) {
	t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp")

	initOnce = *new(sync.Once)
	sr, _ := setupTestTracer(t)

	req, _ := http.NewRequest("GET", "http://example.com/path", nil)
	mockCtx := hooktest.NewMockHookContext()
	transport := &http.Transport{}

	BeforeRoundTrip(mockCtx, transport, req)

	ended := sr.Ended()
	assert.Empty(t, ended, "span should not be ended before AfterRoundTrip")

	// Disable instrumentation while the request is in flight.
	t.Setenv("OTEL_GO_DISABLED_INSTRUMENTATIONS", "nethttp")

	res := &http.Response{
		StatusCode: 200,
		Request:    req,
	}
	AfterRoundTrip(mockCtx, res, nil)

	ended = sr.Ended()
	require.Len(t, ended, 1, "span created by BeforeRoundTrip must be ended by AfterRoundTrip")
	assert.Equal(t, "GET", ended[0].Name())
}

// BenchmarkRoundTripHooks measures the per-request overhead of the hook pair.
// Run with -benchmem to see the allocation count.
func BenchmarkRoundTripHooks(b *testing.B) {
	b.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp")
	initOnce = *new(sync.Once)
	tp := sdktrace.NewTracerProvider()
	otel.SetTracerProvider(tp)
	b.Cleanup(func() { _ = tp.Shutdown(context.Background()) })

	transport := &http.Transport{}
	req := httptest.NewRequest("GET", "http://example.com/path", nil)
	res := &http.Response{StatusCode: http.StatusOK, Request: req}

	b.ReportAllocs()
	for b.Loop() {
		mockCtx := hooktest.NewMockHookContext()
		BeforeRoundTrip(mockCtx, transport, req)
		AfterRoundTrip(mockCtx, res, nil)
	}
}
